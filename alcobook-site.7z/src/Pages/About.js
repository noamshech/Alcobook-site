import React from "react";



export default function About() {


  return (
    <div>

      <div className="container ">

        <div className="border border-danger bg-success d-flex justify-content-center ">
          We Are Alcobook!!!
           </div>
      </div>
    </div>


  )

}
