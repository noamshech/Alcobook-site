import React, { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router';
import serverURL, { getData, patchData } from '../server';
import useToken from './Login/useToken';

function Profile() {
  const {id} = useParams();
  const { token } = useToken();
  const [edit, setEdit] = useState(false);
  const [userDetails, setUserDetails] = useState({ username: '', role: ''});
  const usernameEl = useRef(null);
  const roleEl = useRef(null);
  const isUser = token.user._id === id;
  const isAdmin = token.user.role === 'Admin';
  const isAuthorized = isAdmin || isUser;

  useEffect(() => {
    async function getUser(id) {
      const user = await getData(`${serverURL}/api/user/${id}`);

      setUserDetails(user);
    }

    getUser(id);
  }, [id]);

  return (
    <section>
      <h1>{edit ? <input type='text' ref={usernameEl} defaultValue={userDetails.username} /> : userDetails.username}</h1>
      <h2>{edit ? <input type='text' ref={roleEl} defaultValue={userDetails.role} /> : userDetails.role}</h2>
      {isAuthorized && <button className="btn" onClick={() => setEdit(state => !state)}>{edit ? 'discard' : 'edit'}</button>}
      {isAuthorized && edit && <button className="btn" onClick={async () => {
        const change = { user: token.user };
        const username = usernameEl.current.value;
        const role = roleEl.current.value;

        if (role !== userDetails.role) {
          change.role = role;
        }
        if (username !== userDetails.username) {
          change.username = username;
        }

        await patchData(`${serverURL}/api/user/${id}`, token.user.token, change);
        setUserDetails({username, role});
        setEdit(false);
        }}>save</button>}
    </section>
  );
}

export default Profile;
