
import React from "react";

export default function FormInput() {

  return (
    <div classname="form-group">
      <label htmlFor="exampleInputPassword1">In</label>
      <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" />
    </div>
  );
}
